---
name: standup
description: 生成站会汇总——昨天做了什么、今天计划、风险与阻塞，来自 Plane 中我的工作项与操作记录；可选写入 Plane 页面
---

# standup：站会汇总

## 执行边界

先遵循 Plane 团队规范。没有可用 Plane MCP 时只草拟，不宣称读取或写入成功。调用参数以当前工具 schema 为准。

先调用 `workspace(action="list")` 定位目标；歧义时询问。除该发现调用外，每次读取、分页、写入及核验都显式传 `workspace_slug`，同时携带目标项目和对象标识。跨工作区分别查询、分别分页并标明 slug 与项目来源；不得使用历史默认工作区，不得在无权限时切换工作区重试同名对象。

列表按返回的 cursor、next_page 或 has_more 连续分页，直到结束；如果达到客户端预算、权限受限或某页失败，明确标注仅覆盖已读取范围，不把部分数据当作全量排名、计数或规划依据。不要猜测分页参数。

写入前展示具体目标与变更，获得用户明确确认；已有明确授权仅在原范围内沿用。沉默、空消息或回车不算确认。任何步骤失败立即停止依赖它的后续操作，报告已成功、失败和未执行部分；结果不明时先读取核验，避免重复创建。写后读取核验，只报告已证实的结果。

## 1. 取数据

1. `workitem` 工具 `action="my_summary", workspace_slug="<目标 slug>"`
2. `workitem` 工具 `action="my_items", workspace_slug="<目标 slug>"`，`filters={"state_group__in":"unstarted,started"}`
3. 明确用户时区和汇总区间（周一可从上周五算起），读取已完成工作项及必要的活动记录。只有 `completed_at` 或活动记录中的“进入 completed 状态”时间落在区间内，才能列为该时段完成。`updated_at` 只表示更新，不能作为完成时间证据；缺少完成时间证据时列为“近期更新的已完成项，完成时间待确认”，不计入昨天完成。

## 2. 汇总（Markdown）

```
## 站会 YYYY-MM-DD

**昨天完成**
- WEB-12 修复登录页白屏

**今天计划**
- WEB-30 导出报表加筛选（10/20 截止）

**风险 / 阻塞**
- WEB-8 已逾期 3 天：<原因，未知就写“待确认”>
```

- 今天计划最多 5 条，优先进行中和逾期的。
- 风险只写逾期、7 天内到期但未开始、urgent 未开始的工作项。
- 不要编造原因。需要核对逾期或延期完成的原因时，读取 `workitem(action="comments", workspace_slug="<目标 slug>", work_item="<编号>")` 与 `workitem(action="comment_reviews", workspace_slug="<目标 slug>", work_item="<编号>")`。区分未评审、不合理以及评论修改导致旧评审失效；生成站会本身不授权提交评审。
- 团队汇总可用 `workspace(action="member_work", workspace_slug="<目标 slug>")` 和 `workspace(action="member_work_items", workspace_slug="<目标 slug>", member="<成员>")` 补充负载与风险。成员明细按 `next_page` 传 `page` 翻页；日期筛选依据截止日期，不能用于推断“昨天完成”。

## 3. 可选：写入 Plane

参数里给了项目标识，或用户要求时，用 `page` 工具 `action="create", workspace_slug="<目标 slug>"`，标题「站会 YYYY-MM-DD <姓名>」，内容为上面的 Markdown。写入前先确认。

---
name: issue-next
description: 我接下来该做什么——列出分配给我、未完成的 Plane 工作项，按逾期、优先级、截止日期排序，并提议开始第一个。用户问“今天做什么”“我的待办”“下一个任务”时使用
---

# issue-next：下一个该做的

## 执行边界

先遵循 Plane 团队规范。没有可用 Plane MCP 时只草拟，不宣称读取或写入成功。调用参数以当前工具 schema 为准。

先调用 `workspace(action="list")` 定位目标；歧义时询问。除该发现调用外，每次读取、分页、写入及核验都显式传 `workspace_slug`，同时携带目标项目和对象标识。跨工作区分别查询、分别分页并标明 slug 与项目来源；不得使用历史默认工作区，不得在无权限时切换工作区重试同名对象。

列表按返回的 cursor、next_page 或 has_more 连续分页，直到结束；如果达到客户端预算、权限受限或某页失败，明确标注仅覆盖已读取范围，不把部分数据当作全量排名、计数或规划依据。不要猜测分页参数。

写入前展示具体目标与变更，获得用户明确确认；已有明确授权仅在原范围内沿用。沉默、空消息或回车不算确认。任何步骤失败立即停止依赖它的后续操作，报告已成功、失败和未执行部分；结果不明时先读取核验，避免重复创建。写后读取核验，只报告已证实的结果。

只读。给出一个五秒钟就能做的决定，不做规划（规划用 `issue-plan-cycle`）。

## 1. 取数据

1. Plane MCP `workitem` 工具：`action="my_summary", workspace_slug="<目标 slug>"`。
2. `workitem` 工具：`action="my_items", workspace_slug="<目标 slug>"`，`filters={"state_group__in":"unstarted,started"}`，`per_page=50`。
3. 用户要排查长期停滞时，可另查 `filters={"and":[{"state_group":"started"},{"state_duration__gt":3}]}`。时长为当前状态连续自然天，不是工时；不要用该筛选结果替代完整待办统计。
4. 用户问团队或其他成员负载时，使用 `workspace(action="member_work", workspace_slug="<目标 slug>")`，再用 `workspace(action="member_work_items", workspace_slug="<目标 slug>", member="<成员>")` 下钻。明细按 `next_page` 传 `page` 翻页；日期范围按截止日期计算，不能当作活动时间范围。

## 2. 排序

按以下顺序排，取前 5 个：

1. 已逾期（`target_date` 早于今天）的在最前，逾期越久越靠前
2. 进行中（`started`）先于未开始（`unstarted`）
3. 优先级 urgent > high > medium > low > none
4. 截止日期近的在前，没有截止日期的在后

## 3. 展示

先一行汇总：「分配给你 N 个，逾期 X 个，7 天内到期 Y 个」。然后：

```
WEB-12  High · 逾期 2 天    修复登录页白屏          [进行中]
        理由：逾期且优先级高
WEB-30  Medium · 10/20 截止  导出报表加筛选          [待开始]
        理由：本周到期
```

“理由”一句话，每条不要重复同一句话。

## 4. 提议开工

展示目标工作区、项目和编号，询问是否开始。只有用户明确同意或明确指定其他编号后，才按“开工”流程执行；沉默或回车不算确认。
